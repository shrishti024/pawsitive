<?php
include 'connection.php';
session_start();
if (!isset($_SESSION['vet'])) {
    header("Location:vet_login.php");
    exit();
}
$email = $_SESSION['vet'];
$gender = $_REQUEST['gender'];
$photo1 = $_FILES['photo1']['name'];
$phone = $_REQUEST['phone'];
$address = urlencode($_REQUEST['address']);
$city=$_REQUEST['city'];
$morning = $_REQUEST['morning'];
$evening = $_REQUEST['evening'];
$fee = $_REQUEST['fee'];

if ($photo1 =="") {
    $update = "update vet set gender='$gender',phone='$phone',address='$address',city='$city',morning='$morning',evening='$evening',fee='$fee' where email='$email'";
    echo $update;
} else {
    if ($photo1 != "") {
        $temp1 = $_FILES['photo1']['tmp_name'];
        $ext1 = strtolower(pathinfo($photo1, PATHINFO_EXTENSION));
        $path1 = "vetImages/" . $photo1;
        if ($ext1 == "jpg" || $ext1 == "png" || $ext1 == "gif" || $ext1 == "jpeg" || $ext1 == "jfif") {
            $move1 = move_uploaded_file($temp1, $path1);
            if ($ext1 == "png" || $ext1 == "jpg" || $ext1 == "jpeg" || $ext1 == "jfif") {
                $update = "update vet set gender='$gender',phone='$phone',address='$address',city='$city',morning='$morning',evening='$evening',fee='$fee',photo='$path1' where email='$email'";

            }
        }

    }
}
mysqli_query($conn, $update);
//echo $update;
header("location:vet_profile.php?e=1");
