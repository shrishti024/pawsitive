<?php

include "connection.php";
$fname=$_REQUEST['fname'];
$gender=$_REQUEST['gender'];
$degree=$_REQUEST['degree'];
$dphoto=$_FILES['dphoto']['name'];
$dtmp=$_FILES['dphoto']['tmp_name'];
$photo1=$_FILES['photo1']['name'];
$tmp_name1=$_FILES['photo1']['tmp_name'];
$email=$_REQUEST['email'];
$phone=$_REQUEST['phone'];
$addr=urlencode($_REQUEST['address']);
$city=$_REQUEST['city'];
$morning=$_REQUEST['morning'];
$evening=$_REQUEST['evening'];
$fee=$_REQUEST['fee'];
$status=$_REQUEST['status'];
$ext1 =strtolower (pathinfo($photo1, PATHINFO_EXTENSION));
$dext = strtolower (pathinfo($dphoto, PATHINFO_EXTENSION));
$query = "select * from vet where email='$email'";
echo $query;
$res = mysqli_query($conn, $query);
if (mysqli_num_rows($res)) {
    echo "User already exists";
    header("location:vet_signup.php?e=1");
}
else {
    if ($ext1 == "jpg" || $ext1 == "png" || $ext1 == "gif" || $ext1 == "jpeg" || $ext1 == "jfif"||$ext1 == "jpg" || $ext1 == "png" || $dext == "gif" || $dext == "jpeg" || $dext == "jfif") {
        $path1 = 'vetImages/' . $photo1;
        $dpath='degreeImages/'.$dphoto;
        $move = move_uploaded_file($tmp_name1, $path1);
        $move = move_uploaded_file($dtmp, $dpath);
    }
    $insert = "insert into vet values('$fname','$gender','$degree','$dpath','$path1','$email',null,'$phone','$addr','$city','$morning','$evening','$fee','$status')";
    echo $insert;
    mysqli_query($conn, $insert);

    header("location:vet_signup.php?e=2");
}

