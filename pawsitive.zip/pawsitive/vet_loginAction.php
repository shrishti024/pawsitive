<?php
include "connection.php";
$email=$_REQUEST['email'];
$password=$_REQUEST['password'];
$select="select * from vet where email='$email' and password='$password'";
$res=mysqli_query($conn,$select);
if(mysqli_num_rows($res)){
    $row=mysqli_fetch_array($res);
    $status=$row['status'];
    if($status=="accepted"){
        echo "Log In";
        session_start();
        $_SESSION['vet']=$email;
        header("location:vet_home.php");
    }
    else{
        echo 'not accepted';
        header("location:vet_login.php?e=1");
    }
}
else{
    echo "error message";
    header("location:vet_login.php?e=2");

}

