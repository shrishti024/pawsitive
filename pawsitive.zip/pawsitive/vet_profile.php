<!doctype html>
<html lang="en">
<head>
    <title>My Profile</title>
    <?php include "headerFiles.html" ?>
    <style>
        .error {
            color: red;
        }
    </style>
</head>
<body>
<span class="dark"><?php include 'vet_header.php' ?></span>
<?php
include "connection.php";
$email = $_SESSION['vet'];
$select = "select * from vet where email='$email'";
$res = mysqli_query($conn, $select);
$row = mysqli_fetch_array($res);
?>
<div class="">
    <div class="main-content">
        <section class="inner-header divider parallax layer-overlay  overlay-white-1" data-bg-img="images/bg/bg3.jpg"
                 style="background-size: cover; background-position: center center; height: 65vh;">
            <div class="container pt-60 pb-60">
                <!-- Section Content -->
                <div class="section-content">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <ol class="breadcrumb text-center text-black mt-10 text-uppercase">
                                <li><a href="index.php">Home</a></li>
                                <li class="active text-theme-colored">Vet Profile</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section data-bg-img="images/pattern/p6.png">
            <div class="container">
                <div class="section-title text-center">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <h2 class="text-uppercase font-28 mt-0"><span class="text-theme-colored">Vet</span> Profile
                            </h2>
                            <hr>
                        </div>
                    </div>
                </div>
                <div class="section-content">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <form action="vet_profileAction.php?q=<?php echo $row['email'] ?>" method="post"
                                  class="user_profile-form-transparent" id="user-form" ENCTYPE="multipart/form-data">
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="fname"> Full Name:</label>
                                        <span class="form-control"><?php echo $row['name'] ?></span>
                                        <input type="hidden" name="fname" id="fname" class="form-control"
                                               value="<?php echo $row['name'] ?>"/>
                                    </div>
                                </div>
                                <div class="row mt-10">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="gender">Gender:<i class="fa fa-edit "></i></label>
                                        <input type="radio" name="gender" id="gender" class="form-check-inline"
                                               value="male" <?php if ($row['gender'] == "male") echo "checked" ?>>
                                        <label for="male">Male</label>
                                        <span class="me-3">
                                        <input type="radio" name="gender" id="gender" class="form-check-inline"
                                               value="female" <?php if ($row['gender'] == "female") echo "checked" ?>>
                                                <label for="female">Female</label></span>
                                        <span class="me-3">
                                        <input type="radio" name="gender" id="gender" class="form-check-inline"
                                               value="Other" <?php if ($row['gender'] == "other") echo "checked" ?>>
                                                <label for="Other">Other</label></span>
                                        <span class="me-3">
                                        <input type="radio" name="gender" id="gender" class="form-check-inline"
                                               value="Not Said" <?php if ($row['gender'] == "Not Said") echo "checked" ?>>
                                                <label for="Not Said">Prefer Not to Mention</label></span>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="degree">Degree:</label>
                                        <span class="form-control"><?php echo $row['degree'] ?></span>
                                 </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="dphoto">Degree Photo:</label>
                                        <img src="<?php echo $row['dphoto'] ?>" height="70" width="70" alt="No Image"/>
                                        <input type="hidden" name="dphoto" id="dphoto" class="form-control">
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="photo1">Photo:<i class="fa fa-edit "></i></label>
                                        <img src="<?php echo $row['photo'] ?>" height="70" width="70" alt="No Image"/>
                                        <input type="file" name="photo1" id="photo1" class="form-control"
                                               data-rule-required="true"
                                               data-msg-required="*">
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="email">Email:</label>
                                        <span class="form-control"><?php echo $row['email'] ?></span>
                                        <input type="hidden" name="email" id="email" class="form-control"
                                               value="<?php echo $row['email'] ?>"/>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="phone">Phone:<i class="fa fa-edit "></i></label>
                                        <input type="text" name="phone" id="phone" class="form-control"
                                               value="<?php echo $row['phone'] ?>" data-rule-required="true"
                                               data-msg-required="*"/>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="addr">Address:<i class="fa fa-edit "></i></label>
                                        <textarea name="address" id="addr" class="form-control"
                                                  data-rule-required="true"
                                                  data-msg-required="*"><?php echo urldecode($row['address'] )?></textarea>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="city">City:<i class="fa fa-edit "></i></label>
                                        <input type="text" name="city" id="city" class="form-control"
                                                  data-rule-required="true"
                                                  data-msg-required="*" value="<?php echo $row['city'] ?>">
                                    </div>
                                </div>
                                <div class="row mt-5">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label> Availablity Hours:<i class="fa fa-edit "></i> </label>
                                    </div>
                                    <div class="col-md-4 col-md-offset-2">
                                        <label for="morning">Morning Slot:</label>
                                        <input type="text" name="morning" placeholder="1-24 hours " id="morning"
                                               class="form-control" value="<?php echo $row['morning'] ?>"
                                               data-rule-required="true"
                                               data-msg-required="*"/>
                                    </div>
                                    <div class="col-md-4 ">
                                        <label for="evening">Evening Slot:</label>
                                        <input type="text" name="evening" placeholder="1-24 hours " id="evening"
                                               class="form-control" value="<?php echo $row['evening'] ?>"
                                               data-rule-required="true"
                                               data-msg-required="*"/>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="fee">Consultation Fee:<i class="fa fa-edit "></i></label>
                                        <input type="text" name="fee" id="fee" class="form-control"
                                               data-rule-required="true" value="<?php echo $row['fee'] ?>"
                                               data-msg-required="*"/>
                                    </div>
                                </div>
                                <div class="row mt-20">
                                    <div class="col-md-8 col-md-offset-2">
                                        <button type="submit" class="form-control btn-theme-colored">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php
                    if (isset($_REQUEST['e'])) {
                        if ($_REQUEST['e'] == 1) {
                            echo "<div class='alert alert-success'>Updated successfully</div>";
                        } else {
                            echo "<div class='alert alert-danger'>Error updating the profile</div>";
                        }
                    }
                    ?>
                </div>
            </div>
        </section>
    </div>
</div>
</body>
<?php include 'footer.html';
include 'footer_scripts.html'; ?>
</html>


