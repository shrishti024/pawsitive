<?php

require "vendor/autoload.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

include "connection.php";
$email=$_REQUEST['q'];
$select="select app_date,time_slot,vet_email from appointment where user_email='$email'";
$res=mysqli_query($conn,$select);
$row=mysqli_fetch_array($res) ;
$date=$row[0];
$time=$row[1];
$vet=$row[2];

$vselect="select name,address,phone from vet where email='$vet'";
$vres=mysqli_query($conn,$vselect);
$vrow=mysqli_fetch_array($vres) ;
$name=$vrow[0];
$address=$vrow[1];
$phone=$vrow[2];

$action=$_REQUEST['action'];
if($action=='accepted'){
    $update="update appointment set status='accepted' where user_email='$email'" ;
//echo $update;
    mysqli_query($conn,$update);
    header("location:vet_home.php");
    $fromEmail = "pawsitive.pttt@gmail.com";
    $toEmail = $email;
    $subjectName = " Appointment Confirmation with the Vet on Pawsitive";
    $str = "
Dear Pawsitive User,<br>

We are pleased to inform you that your request for an appointment with the vet on Pawsitive has been accepted. 
Your appointment is scheduled for $date $time at Dr.$name, $address.<br><br>
Please make sure to arrive at least 10 minutes before your appointment time. 
If you are running late or need to reschedule, please contact the vet's office directly at $phone.<br>

We hope that you and your pet have a positive experience with the veterinarian and feel free to reach out to us if you have any questions or concerns.<br>

Thank you for using Pawsitive and have a great day!<br><br>

Best regards,<br>
The Pawsitive Team";
    $message = $str;

    $mail = new PHPMailer(true);

    $mail->SMTPDebug = SMTP::DEBUG_SERVER;
    $mail->isSMTP();
    $mail->SMTPAuth = true;
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
    $mail->Username = "pawsitive.pttt@gmail.com";
    $mail->Password = "mtwkxzxdwwtlygbi";
    $mail->setFrom($fromEmail, 'Pawsitive');
    $mail->addAddress($toEmail, "vet");
    $mail->isHTML(true);
    $mail->Subject = $subjectName;
    $mail->Body = $message;

    $mail->send();
}
else{
    $update="update appointment set status='rejected' where vet_email='$vet'" ;
    mysqli_query($conn,$update);
    $fromEmail = "pawsitive.pttt@gmail.com";
    $toEmail = $email;
    $subjectName = "Your Request for Appointment with the Vet on Pawsitive";
    $str = "Dear Pawsitive User,<br>


We regret to inform you that your request for an appointment with the vet on Pawsitive has been rejected due to some 
unignorable circumstances. We understand how important your pet's health is to you and we are sorry for any inconvenience this may have caused.<br><br>
We encourage you to explore other available veterinarians on our website and hope that you find a suitable alternative soon. 
If you have any questions or concerns, please don't hesitate to reach out to us at $fromEmail.<br>

Thank you for your understanding.<br>

Best regards,<br>
The Pawsitive Team";
    $message = $str;

    $mail = new PHPMailer(true);

    $mail->SMTPDebug = SMTP::DEBUG_SERVER;
    $mail->isSMTP();
    $mail->SMTPAuth = true;
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
    $mail->Username = "pawsitive.pttt@gmail.com";
    $mail->Password = "mtwkxzxdwwtlygbi";
    $mail->setFrom($fromEmail, 'Pawsitive');
    $mail->addAddress($toEmail, "vet");
    $mail->isHTML(true);
    $mail->Subject = $subjectName;
    $mail->Body = $message;

    $mail->send();

    header("location:vet_home.php");
}














