<!doctype html>
<html lang="en">
<head>
    <title>My Product Orders</title>
    <?php include 'headerFiles.html' ?>
</head>
<body>
<span class="dark"><?php include 'user_header.php' ?>
<div class="container">
    <h2 class="text-gray-darkgray">View Product Order Details</h2>
    <?php
    include 'connection.php';
    $query = "SELECT  product_orders.orderid, 
        product.pro_name,
        product.price, 
        product.description,
        product.photo1,
        product_orders.date,
        product_orders.status FROM product_orders 
    JOIN product_orderdetails ON product_orders.orderid = product_orderdetails.orderid 
    JOIN product ON product_orderdetails.product = product.pro_id
    WHERE product_orders.user_email = '" . $_SESSION['user'] . "'
    ORDER BY product_orders.orderid DESC;";
    $result = mysqli_query($conn, $query);
    if(mysqli_num_rows($result)){
        ?>
        <table class="table text-black">
            <thead>
            <tr>
                <th>Sr.No</th>
                <th>Order ID</th>
                <th>Product Name</th>
                <th>Price(&#x20B9;)</th>
                <th>Description</th>
                <th>Photo</th>
                <th>Order Date</th>
                <th>Order Status</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $i=1;
            while($row=mysqli_fetch_array($result)){
                ?>
                <tr>
                    <td><?php echo $i?></td>
                    <td><?php echo $row['orderid']?></td>
                    <td><?php echo $row['pro_name']?></td>
                    <td><?php echo $row['price']?></td>
                    <td><?php echo $row['description']?></td>
                    <td>
                        <?php if(!empty($row['photo1'])){ ?>
                            <img src="<?php echo $row['photo1']?>" width="100px" height="100px">
                        <?php } else { ?>
                            No photo available
                        <?php } ?>
                    </td>
                    <td><?php echo $row['date']?></td>
                    <td><?php echo $row['status']?></td>
                </tr>
                <?php
                $i++;
            }
            ?>
            </tbody>
        </table>
        <?php
    } else {
        echo "<div class='alert alert-danger'>
            <strong>No Data Found!</strong>
            </div>";
    }

    ?>
</div>
<?php include "footer.html";
include "footer_scripts.html" ?>
</body>
</html>

