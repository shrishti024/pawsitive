<!doctype html>
<html lang="en">
<head>
    <title>Vet Signup</title>
    <?php include "headerFiles.html" ?>
    <style>
        .error {
            color: red;
        }
    </style>
</head>
<body>
<div class="">
    <span class="dark"><?php include "publicheader.html" ?></span>
    <div class="main-content">
        <section class="inner-header divider parallax layer-overlay  overlay-white-1" data-bg-img="images/bg/bg3.jpg"
                 style="background-size: cover; background-position: center center; height: 65vh;">
            <div class="container pt-60 pb-60">
                <!-- Section Content -->
                <div class="section-content">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <ol class="breadcrumb text-center text-black mt-10 text-uppercase">
                                <li><a href="index.php">Home</a></li>
                                <li class="active text-theme-colored">Vet Signup</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section data-bg-img="images/pattern/p6.png">
            <div class="container">
                <div class="section-title text-center">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <h2 class="text-uppercase font-28 mt-0"><span class="text-theme-colored">Vet</span>
                                Signup</h2>
                            <hr>
                        </div>
                    </div>
                </div>
                <div class="section-content">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2">
                            <form action="vet_signupAction.php" method="post" enctype="multipart/form-data"
                                  class="vet_signup-form-transparent"
                                  id="vet-form">
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="fname"> Full Name:</label>
                                        <input type="text" name="fname" id="fname" class="form-control"
                                               data-rule-required="true"
                                               data-msg-required="*"/>
                                    </div>
                                </div>
                                <div class="row mt-10">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="gender">Gender:</label>
                                        <div>
                                            <input type="radio" name="gender" id="gender" class="form-check-inline"
                                                   value="male">
                                            <label for="male">Male</label>
                                            <span class="col-md-offset-1">
                                        <input type="radio" name="gender" id="gender" class="form-check-inline"
                                               value="female">
                                                <label for="female">Female</label></span>
                                            <span class="col-md-offset-1">
                                        <input type="radio" name="gender" id="gender" class="form-check-inline"
                                               value="Other">
                                                <label for="Other">Other</label></span>
                                            <span class="col-md-offset-1">
                                        <input type="radio" name="gender" id="gender" class="form-check-inline"
                                               value="Not Said">
                                                <label for="Not Said">Prefer Not to Mention</label></span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="degree">Degree:</label>
                                        <select name="degree" class="form-control" id="degree" data-rule-required="true"
                                                data-msg-required="*">
                                            <option value="">Select</option>
                                            <option value="BSVM">BSVM(Bachelor of Science And Veterinary Medicine)</option>
                                            <option value="BVM">BVM(Bachelor of veterinary Medicine)</option>
                                            <option value="BVM&AR">BVM&AR(Bachelor of veterinary Medicine And Animal Resource)</option>
                                            <option value="BVM&S">BVM&S(Bachelor of veterinary Medicine And Surgery)</option>
                                            <option value="BVSc&AH">BVS&AH(Bachelor of veterinary Science And Animal Husbandary)</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="dphoto">Degree Photo:</label>
                                        <input type="file" name="dphoto" id="dphoto" class="form-control"
                                               data-rule-required="true"
                                               data-msg-required="*">
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="photo1">Photo:</label>
                                        <input type="file" name="photo1" id="photo1" class="form-control"
                                               data-rule-required="true"
                                               data-msg-required="*">
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="email">Email:</label>
                                        <input type="email" name="email" id="email" class="form-control"
                                               data-rule-required="true"
                                               data-msg-required="*"/>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="phone">Phone:</label>
                                        <input type="text" name="phone" id="phone" class="form-control"
                                               data-rule-required="true"
                                               data-msg-required="*"/>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="addr">Address:</label>
                                        <input type="text" name="address" id="addr" class="form-control"
                                               data-rule-required="true"
                                               data-msg-required="*"/>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="city">City:</label>
                                        <input type="text" name="city" id="city" class="form-control"
                                               data-rule-required="true"
                                               data-msg-required="*"/>
                                    </div>
                                </div>
                                <div class="row mt-5">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label> Availablity Hours: </label>
                                    </div>
                                    <div class="col-md-4 col-md-offset-2">
                                        <label for="morning">Morning Slot:</label>
                                        <input type="text" name="morning" placeholder="1-24 hours " id="morning"
                                               class="form-control"
                                               data-rule-required="true"
                                               data-msg-required="*"/>
                                    </div>
                                    <div class="col-md-4 ">
                                        <label for="evening">Evening Slot:</label>
                                        <input type="text" name="evening" placeholder="1-24 hours " id="evening"
                                               class="form-control"
                                               data-rule-required="true"
                                               data-msg-required="*"/>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        <label for="fee">Consultation Fee:</label>
                                        <input type="text" name="fee" id="fee" class="form-control"
                                               data-rule-required="true"
                                               data-msg-required="*"/>
                                    </div>
                                </div>
                                <div class="row mt-20">
                                    <div class="col-md-8 col-md-offset-2">
                                        <button type="submit" class="btn btn-theme-colored form-control" name="status"
                                                value="requested">Signup
                                        </button>
                                    </div>
                                </div>
                                <div class="row mb-2">
                                    <div class="col-md-8 col-md-offset-2">
                                        Already have an account?<a href="vet_login.php">Login here</a>
                                    </div>
                                </div>
                                <div class="row mt-20">
                                    <div class="col-md-8 col-md-offset-2">
                                        <p class="text-danger">Once your request is reviewed you'll be sent an
                                            acceptance email by our team with a password for login.</p>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php
if (isset($_REQUEST['e'])) {
    if ($_REQUEST['e'] == 1) {
        echo "<div class='alert alert-danger'>Email already exists</div>";
    } else {
        echo "<div class='alert alert-success'>Request sent successfully</div>";
    }
}
?>
<?php include 'footer.html';
include 'footer_scripts.html'; ?>
</body>
</html>







