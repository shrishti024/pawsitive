<!doctype html>
<html lang="en">
<head>
    <title>View Vets</title>
    <?php include "headerFiles.html" ?>

</head>
<body>
<span class="dark"><?php include "admin_header.php" ?></span>
<div class="container">
    <h2>View Vets</h2>
    <hr>
    <?php
    include "connection.php";
    $select = "select * from vet where status='requested'";
    $res = mysqli_query($conn, $select);
    ?>
    <div class=" row alert alert-warning text-dark"><b>REQUESTING VETS</b></div>
    <table class="table text-black">
        <thead>
        <tr>
            <th>Sr.No</th>
            <th>Name</th>
            <th>Degree</th>
            <th>Degree Photo</th>
            <th>Photo</th>
            <th>Email</th>
            <th>Phone No.</th>
            <th>Address</th>
            <th colspan="2">Controls</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if (mysqli_num_rows($res)) {
            $i = 1;
            while ($row = mysqli_fetch_array($res)) {
                ?>
                <tr>
                    <td><?php echo $i ?></td>
                    <td><?php echo $row['name'] ?></td>
                    <td><?php echo $row['degree'] ?>
                    <td><img src="<?php echo $row['dphoto'] ?>" width="25%" height="25%" alt="No Image"></td>

                    <td><img src="<?php echo $row['photo'] ?>" width="25%" height="25%" alt="No Image"></td>
                    <td><?php echo $row['email'] ?></td>
                    <td><?php echo $row['phone'] ?></td>
                    <td><?php echo urldecode($row['address']) ?></td>
                    <td><a href="admin_vetUpdate.php?q=<?php echo $row[5]?>&action=accepted">
                            <button type="button" class="btn btn-success">
                                <i class='fa fa-check-square'></i></button>
                        </a></td>
                    <td><a href="admin_vetUpdate.php?q=<?php echo $row[5]?>&action=rejected">
                            <button type="button" class="btn btn-danger">
                                <i class='fa fa-times'></i></button>
                        </a></td>
                </tr>
                <?php
                $i++;
            }
        } else {
            echo "<tr class='alert alert-danger'>
            <td colspan='9'>No Data Found</td>
            </tr>";
        }
        ?>
        </tbody>
    </table>
    <div class=" row alert alert-success text-dark"><b>ACCEPTED VETS</b></div>
    <?php
    include "connection.php";
    $select = "select * from vet where status='accepted'";
    $res = mysqli_query($conn, $select);
    ?>
    <table class="table text-black">
        <thead>
        <tr>
            <th>Sr.No</th>
            <th>Name</th>
            <th>Degree</th>
            <th>Degree Photo</th>
            <th>Photo</th>
            <th>Email</th>

            <th>Phone No.</th>
            <th>Address</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if (mysqli_num_rows($res)) {
            $i = 1;
            while ($row = mysqli_fetch_array($res)) {
                ?>
                <tr>
                    <td><?php echo $i ?></td>
                    <td><?php echo $row['name'] ?></td>
                    <td><?php echo $row['degree'] ?>
                    <td><img src="<?php echo $row['dphoto'] ?>" width="25%" height="25%" alt="No Image"></td>
                    <td><img src="<?php echo $row['photo'] ?>" width="25%" height="25%" alt="No Image"></td>
                    <td><?php echo $row['email'] ?></td>
                    <td><?php echo $row['phone'] ?></td>
                    <td><?php echo urldecode($row['address']) ?></td>

                </tr>
                <?php
                $i++;
            }
        } else {
            echo "<tr class='alert alert-danger'>
            <td colspan='8'>No Data Found</td>
            </tr>";
        }
        ?>
        </tbody>
    </table>
</div>
<?php
include 'footer.html';
include "footer_scripts.html";?>
</body>
</html>

