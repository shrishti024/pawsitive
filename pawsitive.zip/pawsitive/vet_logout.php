<?php
session_start();
session_destroy();
if($_REQUEST['q']=="vet"){
    $_SESSION['vet']=null;
    header("location:index.php");
}

