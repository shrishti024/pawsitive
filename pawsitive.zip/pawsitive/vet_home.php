<!doctype html>
<!doctype html>
<html lang="en">
<head>

    <title>Vet homepage</title>
    <?php include 'headerFiles.html' ?>
</head>
<body>
<span class="dark"><?php include 'vet_header.php' ?></span>
<div class="container">
    <h2>View Appointments</h2>
    <hr>
    <div class=" row alert alert-warning text-dark"><b>REQUESTING Appointments</b></div>
    <?php
    include "connection.php";
    $vet = $_SESSION['vet'];
    $select = "select * from appointment where vet_email='$vet' and status='requested'";
    $res = mysqli_query($conn, $select);
    ?>
    <table class="table">
        <thead>
        <tr>
            <th>Sr.No</th>
            <th>User_Email</th>
            <th>Dog Name</th>
            <th>Phone</th>
            <th>Appointment Date</th>
            <th>Symptoms</th>
            <th>Time</th>
            <th>Booking Time</th>
            <th colspan="2">Controls</th>
        </tr>
        </thead>
        <tbody>
        <?php
        if (mysqli_num_rows($res)) {
            $i = 1;
            while ($row = mysqli_fetch_array($res)) {
                ?>
                <tr>
                    <td><?php echo $i ?></td>
                    <td><?php echo $row['user_email'] ?></td>
                    <td><?php echo $row['dog_name'] ?></td>
                    <td><?php echo $row['phone'] ?></td>
                    <td><?php echo $row['app_date'] ?></td>
                    <td> <?php echo urldecode($row['symptoms']) ?></td>
                    <td> <?php echo $row['time_slot'] ?></td>
                    <td><?php echo $row['booked_on'] ?></td>
                    <td><a href="vet_homeAction.php?q=<?php echo $row['user_email'] ?>&action=accepted">
                            <button type="button" class="btn btn-success">
                                <i class='fa fa-check-square'></i></button>
                        </a></td>
                    <td><a href="vet_homeAction.php?q=<?php echo $row['user_email'] ?>&action=rejected">
                            <button type="button" class="btn btn-danger">
                                <i class='fa fa-times'></i></button>
                        </a></td>
                </tr>
                <?php
                $i++;
            }
        } else {
            echo "<tr class='alert alert-danger'>
            <td colspan='9'>No Data Found</td>
            </tr>";
        }
        ?>
        </tbody>
    </table>
    <div class=" row alert alert-success text-dark"><b>ACCEPTED Appointments</b></div>
    <?php
    $select = "select * from appointment where status='accepted'";
    $res = mysqli_query($conn, $select);
    ?>
    <table class="table">
        <thead>
        <tr>
            <th>Sr.No</th>
            <th>User_Email</th>
            <th>Dog Name</th>
            <th>Phone</th>
            <th>Appointment Date</th>
            <th>Symptoms</th>
            <th>Time</th>
            <th>Booking Time</th>

        </tr>
        </thead>
        <tbody>
        <?php
        if (mysqli_num_rows($res)) {
            $i = 1;
            while ($row = mysqli_fetch_array($res)) {
                ?>
                <tr>
                    <td><?php echo $i ?></td>
                    <td><?php echo $row['user_email'] ?></td>
                    <td><?php echo $row['dog_name'] ?></td>
                    <td><?php echo $row['phone'] ?></td>
                    <td><?php echo $row['app_date'] ?></td>
                    <td> <?php echo urldecode($row['symptoms']) ?></td>
                    <td> <?php echo $row['time_slot'] ?></td>
                    <td><?php echo $row['booked_on'] ?></td>
                </tr>
                <?php
                $i++;
            }
        } else {
            echo "<tr class='alert alert-danger'>
            <td colspan='9'>No Data Found</td>
            </tr>";
        }
        ?>
        </tbody>
    </table>
    <div class=" row alert alert-dark text-dark"><b>REJECTED Appointments</b></div>
    <?php
    include "connection.php";
    $select = "select * from appointment where status='rejected'";
    $res = mysqli_query($conn, $select);
    ?>
    <table class="table">
        <thead>
        <tr>
            <th>Sr.No</th>
            <th>User_Email</th>
            <th>Dog Name</th>
            <th>Phone</th>
            <th>Appointment Date</th>
            <th>Symptoms</th>
            <th>Time</th>
            <th>Booking Time</th>

        </tr>
        </thead>
        <tbody>
        <?php
        if (mysqli_num_rows($res)) {
            $i = 1;
            while ($row = mysqli_fetch_array($res)) {
                ?>
                <tr>
                    <td><?php echo $i ?></td>
                    <td><?php echo $row['user_email'] ?></td>
                    <td><?php echo $row['dog_name'] ?></td>
                    <td><?php echo $row['phone'] ?></td>
                    <td><?php echo $row['app_date'] ?></td>
                    <td> <?php echo urldecode($row['symptoms']) ?></td>
                    <td> <?php echo $row['time_slot'] ?></td>
                    <td><?php echo $row['booked_on'] ?></td>
                </tr>
                <?php
                $i++;
            }
        } else {
            echo "<tr class='alert alert-danger'>
            <td colspan='9'>No Data Found</td>
            </tr>";
        }
        ?>
        </tbody>
    </table>
</div>

</body>
<?php include "footer.html";
include "footer_scripts.html" ?>
</html>

