<?php

$conn = mysqli_connect("localhost", "root", "", "pawsitive");
/*if($conn)
{
    echo "Connection Created <br>";
}
else{
    echo "Connection Not Created <br>";
}*/
